<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// --- ডাটাবেস সেটিংস ---
$host = 'localhost';
$db_name = 'u820759092_life';
$db_user = 'u820759092_life';
$db_pass = 'S7!i4;Ug7@p';

$conn = new mysqli($host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$action = $_GET['action'] ?? '';

// ১. রেজিস্ট্রেশন লজিক
if ($action == 'register') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $pass = $_POST['password'];
    $dob = $_POST['dob'];
    $address = $_POST['address'];

    $stmt = $conn->prepare("INSERT INTO users (name, email, mobile, password, dob, address) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $name, $email, $mobile, $pass, $dob, $address);
    
    if($stmt->execute()) {
        header("Location: index.html?success=registered");
    } else {
        echo "Error: " . $conn->error;
    }
}

// ২. লগইন লজিক
if ($action == 'login') {
    $email = $_POST['email'];
    $pass = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND password = ?");
    $stmt->bind_param("ss", $email, $pass);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if ($user) {
        $conn->query("UPDATE users SET last_login = NOW() WHERE id = " . $user['id']);
        $_SESSION['user'] = $user;
        
        echo "<script>
            localStorage.setItem('currentUserEmail', '{$user['email']}');
            localStorage.setItem('currentUserName', '{$user['name']}');
            window.location.href = '" . ($user['role'] == 'admin' ? 'admin.php' : 'main.php') . "';
        </script>";
    } else {
        echo "<script>alert('ভুল ইমেইল বা পাসওয়ার্ড!'); window.location.href='index.html';</script>";
    }
}

// ৩. প্রোফাইল আপডেট লজিক (নতুন যুক্ত করা হয়েছে)
if ($action == 'update_profile') {
    if (!isset($_SESSION['user'])) {
        die("অননুমোদিত অ্যাক্সেস!");
    }

    $email = $_POST['email']; 
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $dob = $_POST['dob'];
    $address = $_POST['address'];
    $blood_group = $_POST['blood_group'];
    $institution = $_POST['institution'];
    $hobby = $_POST['hobby'];

    // ডাটাবেস আপডেট কুয়েরি
    $stmt = $conn->prepare("UPDATE users SET name=?, mobile=?, dob=?, address=?, blood_group=?, institution=?, hobby=? WHERE email=?");
    $stmt->bind_param("ssssssss", $name, $mobile, $dob, $address, $blood_group, $institution, $hobby, $email);
    
    if($stmt->execute()) {
        // আপডেট হওয়ার পর সেশনের তথ্য আপডেট করা
        $res = $conn->query("SELECT * FROM users WHERE email='$email'");
        $_SESSION['user'] = $res->fetch_assoc();
        
        echo "<script>
            alert('আপনার প্রোফাইল সফলভাবে আপডেট করা হয়েছে!');
            window.location.href='main.php';
        </script>";
    } else {
        echo "Error: " . $conn->error;
    }
}

// ৪. অ্যাডমিন হিসেবে প্রবেশ (ইমপারসোনেট)
if ($action == 'impersonate' && isset($_SESSION['user']) && $_SESSION['user']['role'] == 'admin') {
    $email = $_GET['email'];
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if ($user) {
        $_SESSION['user'] = $user;
        header("Location: main.php");
    }
}

// ৫. লগআউট
if ($action == 'logout') {
    session_destroy();
    header("Location: index.html");
}
?>