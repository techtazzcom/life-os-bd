<?php
session_start();

// ১. শুধুমাত্র অ্যাডমিন এক্সেস চেক
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    die("শুধুমাত্র অ্যাডমিন এক্সেস পাবেন!");
}

// ২. ডাটাবেস কানেকশন
$host = 'localhost';
$db_name = 'u820759092_life';
$db_user = 'u820759092_life';
$db_pass = 'S7!i4;Ug7@p';

$conn = new mysqli($host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ৩. নতুন উপদেশ যোগ করার লজিক
if(isset($_POST['add_advice'])) {
    $new_advice = $conn->real_escape_string($_POST['advice_text']);
    if(!empty($new_advice)) {
        $conn->query("INSERT INTO daily_advice (content) VALUES ('$new_advice')");
        echo "<script>alert('নতুন উপদেশ যোগ হয়েছে!'); window.location.href='admin.php';</script>";
    }
}

// ৪. উপদেশ ডিলিট করার লজিক
if(isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];
    $conn->query("DELETE FROM daily_advice WHERE id = $id");
    header("Location: admin.php");
}

// ৫. সব উপদেশ এবং ইউজার লিস্ট আনা
$advices = $conn->query("SELECT * FROM daily_advice ORDER BY id DESC");
$result = $conn->query("SELECT * FROM users WHERE role = 'user' ORDER BY last_login DESC");
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Multi-Advice</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;700&display=swap');
        body { font-family: 'Hind Siliguri', sans-serif; }
    </style>
</head>
<body class="bg-slate-100 p-4 md:p-10">
    <div class="max-w-6xl mx-auto">
        
        <div class="flex justify-between items-center mb-8">
            <div>
                <h1 class="text-3xl font-black text-slate-800">অ্যাডমিন কন্ট্রোল</h1>
                <p class="text-slate-500 font-bold">একাধিক উপদেশ ও ইউজার ম্যানেজমেন্ট</p>
            </div>
            <a href="auth.php?action=logout" class="bg-red-500 text-white px-6 py-2 rounded-2xl font-bold shadow-lg hover:bg-red-600 transition">লগআউট</a>
        </div>
        
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-10">
            <div class="bg-white p-6 rounded-[32px] shadow-sm border border-blue-100">
                <h2 class="text-xl font-black mb-4 text-blue-600"><i class="fas fa-plus-circle mr-2"></i> নতুন সংবাদ যোগ করুন</h2>
                <form method="POST" class="space-y-4">
                    <textarea name="advice_text" rows="3" required class="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-[24px] outline-none focus:border-blue-400 transition font-bold" placeholder="এখানে লিখুন..."></textarea>
                    <button type="submit" name="add_advice" class="w-full bg-blue-600 text-white py-3 rounded-2xl font-bold hover:bg-blue-700 shadow-lg transition">সংরক্ষণ করুন</button>
                </form>
            </div>

            <div class="bg-white p-6 rounded-[32px] shadow-sm border border-slate-200">
<h2 class="text-xl font-black mb-4 text-slate-700"><i class="fas fa-list mr-2"></i> সকল সংবাদ</h2>
                <div class="max-h-[200px] overflow-y-auto space-y-3 pr-2">
                    <?php if($advices->num_rows > 0): ?>
                        <?php while($adv = $advices->fetch_assoc()): ?>
                            <div class="flex justify-between items-center bg-slate-50 p-3 rounded-xl border border-slate-100">
                                <p class="text-sm font-bold text-slate-600 truncate mr-4"><?php echo htmlspecialchars($adv['content']); ?></p>
                                <a href="admin.php?delete_id=<?php echo $adv['id']; ?>" onclick="return confirm('ডিলিট করতে চান?')" class="text-red-500 hover:text-red-700 p-2">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-slate-400 text-center py-10">কোনো উপদেশ যোগ করা নেই।</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-[32px] shadow-sm border border-slate-200 overflow-hidden">
            <div class="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                <h3 class="font-black text-slate-800"><i class="fas fa-users mr-2 text-blue-500"></i> রেজিস্টার্ড ইউজারসমূহ</h3>
                <span class="bg-blue-100 text-blue-700 px-4 py-1 rounded-full text-xs font-black">মোট: <?php echo $result->num_rows; ?> জন</span>
            </div>
            
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="text-slate-400 text-[11px] uppercase tracking-widest font-black">
                            <th class="p-6">ইউজার তথ্য</th>
                            <th class="p-6">ঠিকানা ও জন্ম</th>
                            <th class="p-6">শেষ লগইন</th>
                            <th class="p-6 text-right">অ্যাকশন</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($u = $result->fetch_assoc()): ?>
                        <tr class="border-t border-slate-50 hover:bg-blue-50/30 transition">
                            <td class="p-6">
                                <div class="flex items-center gap-3">
                                    <div class="w-10 h-10 bg-slate-200 rounded-full flex items-center justify-center font-bold text-slate-500 uppercase">
                                        <?php echo substr($u['name'], 0, 1); ?>
                                    </div>
                                    <div>
                                        <p class="font-bold text-slate-800 leading-none mb-1"><?php echo $u['name']; ?></p>
                                        <p class="text-xs text-blue-500 font-medium"><?php echo $u['email']; ?></p>
                                    </div>
                                </div>
                            </td>
                            <td class="p-6">
                                <p class="text-xs font-bold text-slate-700"><?php echo $u['address']; ?></p>
                                <p class="text-[10px] text-orange-500 font-black mt-1 uppercase"><?php echo $u['dob']; ?></p>
                            </td>
                            <td class="p-6 text-xs font-mono text-slate-500">
                                <?php echo $u['last_login'] ?? 'কখনো না'; ?>
                            </td>
                            <td class="p-6 text-right">
                                <a href="auth.php?action=impersonate&email=<?php echo urlencode($u['email']); ?>" class="inline-flex items-center gap-2 bg-blue-50 text-blue-600 px-4 py-2 rounded-xl text-xs font-black hover:bg-blue-600 hover:text-white transition shadow-sm">
                                   <i class="fas fa-eye"></i> ভিউ
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>