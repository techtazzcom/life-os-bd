<?php

session_start();

// ১. ইউজার লগইন করা না থাকলে ইনডেক্স পেজে পাঠিয়ে দেবে
if(!isset($_SESSION['user'])) {
    header("Location: index.html");
    exit();
}

// ২. ডাটাবেস কানেকশন
$host = 'localhost';
$db_name = 'u820759092_life';
$db_user = 'u820759092_life';
$db_pass = 'S7!i4;Ug7@p';

$conn = new mysqli($host, $db_user, $db_pass, $db_name);

// ৩. সেশনের ইমেইল দিয়ে ডাটাবেস থেকে লেটেস্ট তথ্য আনা
$user_email = $_SESSION['user']['email'];
$query = "SELECT * FROM users WHERE email = '$user_email'";
$result = $conn->query($query);
$u = $result->fetch_assoc();

// সব উপদেশ ডাটাবেস থেকে আনা
$advice_res = $conn->query("SELECT content FROM daily_advice ORDER BY id DESC");
$all_advices = [];
if($advice_res && $advice_res->num_rows > 0) {
    while($row = $advice_res->fetch_assoc()) {
        $all_advices[] = $row['content'];
    }
} else {
    $all_advices = ["আজকের দিনটি আপনার জন্য শুভ হোক।"];
}
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Life OS Ultimate | Pro Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&family=Hind+Siliguri:wght@300;400;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
    
    <style>
        body { font-family: 'Hind Siliguri', sans-serif; transition: 0.3s; }
        .hidden { display: none !important; }
        .card { background: white; border-radius: 24px; transition: 0.3s; border: 1px solid #e2e8f0; position: relative; }
        .completed { text-decoration: line-through; opacity: 0.5; }
        
        /* কাস্টম স্ক্রলবার ও হাইডিং লজিক */
        .custom-scroll::-webkit-scrollbar { width: 5px; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }

        .drag-handle { cursor: grab; padding: 10px; color: #cbd5e1; transition: 0.2s; z-index: 10; }
        .drag-handle:active { cursor: grabbing; color: #3b82f6; }
        .sortable-ghost { opacity: 0.3; border: 2px dashed #3b82f6 !important; }
        
        .modal-overlay { display: none; position: fixed; inset: 0; z-index: 100; align-items: center; justify-content: center; padding: 20px; background: rgba(15, 23, 42, 0.7); backdrop-filter: blur(8px); }
        .modal-overlay.active { display: flex; animation: fadeIn 0.3s ease; }
        .modal-box { transform: scale(0.9); opacity: 0; transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1); max-height: 90vh; overflow-y: auto; }
        .modal-overlay.active .modal-box { transform: scale(1); opacity: 1; }
        
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        .modal-animate { animation: fadeIn 0.3s ease-out; }

        /* Task Animations */
        @keyframes flashWarning {
            0% { background-color: #fef08a; color: #854d0e; }
            50% { background-color: #ffffff; color: #334155; }
            100% { background-color: #fef08a; color: #854d0e; }
        }
        .task-warning { animation: flashWarning 1s infinite; border-color: #fde047; }
        .task-danger { background-color: #fee2e2; color: #991b1b; border-color: #fca5a5; }
        .task-danger .task-text { color: #991b1b; }

        .mood-btn { font-size: 24px; filter: grayscale(1); transition: 0.3s; cursor: pointer; }
        .mood-btn.active { filter: grayscale(0); transform: scale(1.2); }
        
        .namaz-btn { transition: 0.3s; background: #ef4444; color: #ffffff; font-weight: 700; padding: 12px; border-radius: 15px; display: flex; justify-content: space-between; align-items: center; width: 100%; border: none; }
        .namaz-btn.active { background: #22c55e; }
        
        .perm-note-card { background: #fff; border-left: 5px solid #ec4899; transition: 0.3s; cursor: pointer; }
        .perm-note-card:hover { transform: translateY(-2px); box-shadow: 0 10px 15px -3px rgba(236, 72, 153, 0.1); }

        .diary-tab { padding: 6px 12px; border-radius: 6px; font-size: 14px; font-weight: 600; transition: 0.2s; background: #f1f5f9; color: #475569; border: 1px solid #e2e8f0; display: flex; align-items: center; gap: 10px; cursor: pointer; }
        .diary-tab.active { background: #9333ea; color: white; border-color: #7e22ce; }
        .delete-note-btn { color: #fca5a5; transition: 0.2s; font-size: 14px; }
        .delete-note-btn:hover { color: #ef4444; transform: scale(1.1); }
        .diary-tab.active .delete-note-btn { color: #f3e8ff; }

        .user-dropdown { position: relative; }
        .dropdown-menu { display: none; position: absolute; right: 0; top: 110%; background: white; border: 1px solid #e2e8f0; border-radius: 16px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1); width: 170px; overflow: hidden; z-index: 60; }
        .dropdown-menu.show { display: block; animation: fadeIn 0.2s ease; }
        .dropdown-item { padding: 12px 16px; font-size: 14px; font-weight: 600; color: #475569; cursor: pointer; display: flex; align-items: center; gap: 10px; transition: 0.2s; }
        .dropdown-item:hover { background: #f1f5f9; color: #2563eb; }
        .profile-pill { display: flex; align-items: center; gap: 8px; background: white; border: 1px solid #e2e8f0; padding: 6px 14px; border-radius: 999px; cursor: pointer; transition: 0.2s; }
        
        .acc-card { position: relative; }
        .acc-delete { position: absolute; top: 5px; right: 5px; opacity: 0; transition: 0.2s; color: #fca5a5; font-size: 12px; }
        .acc-card:hover .acc-delete { opacity: 1; }
        .goal-timer { font-family: 'Hind Siliguri', sans-serif; font-size: 13px; font-weight: 600; color: #2563eb;}
        
        .dash-card { background: white; border-radius: 20px; padding: 20px; text-align: center; border: 1px solid #e2e8f0; box-shadow: 0 2px 5px rgba(0,0,0,0.02); transition: 0.3s; }
        .dash-card:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
    </style>
</head>
<body class="bg-slate-50 min-h-screen pb-10 text-slate-800">

    <nav class="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b p-4 shadow-sm">
        <div class="max-w-6xl mx-auto flex justify-between items-center">
            <div class="flex items-center gap-4">
                <div class="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-lg text-xl"><i class="fas fa-bolt"></i></div>
                <div>
                    <h1 class="text-2xl md:text-3xl font-black tracking-tight text-slate-900" style="font-family: 'Poppins', sans-serif;">Life <span class="text-blue-600">OS</span></h1>
                </div>
            </div>
            <div class="flex items-center gap-2">
                <div class="flex items-center bg-white border rounded-xl px-2 py-1 shadow-sm">
                    <input type="date" id="historyDate" class="text-xs outline-none bg-transparent font-bold text-slate-600">
                    <button onclick="applyDateFilter()" class="bg-blue-600 text-white text-[10px] px-3 py-1.5 rounded-lg font-bold ml-1">Apply</button>
                </div>
                
                <div class="user-dropdown ml-2">
                    <div class="profile-pill" onclick="toggleUserMenu()">
                        <i class="fas fa-user-circle text-blue-600 text-xl"></i>
                        <span id="pillName" class="text-sm font-bold text-slate-700">নাম</span>
                    </div>
                    <div id="userMenu" class="dropdown-menu">
                        <div class="dropdown-item" onclick="openSettings()"><i class="fas fa-cog text-xs"></i> সেটিংস</div>
                        <div class="dropdown-item" onclick="toggleProfile(); toggleUserMenu();"><i class="fas fa-user-circle text-xs text-blue-500"></i> প্রোফাইল</div>
                        <div class="dropdown-item text-red-500" onclick="logout()"><i class="fas fa-sign-out-alt text-xs"></i> লগআউট</div>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <main class="max-w-6xl mx-auto p-4 md:p-8">
        
        <div class="bg-white rounded-[24px] p-6 mb-6 shadow-sm border border-slate-100 flex items-center gap-5 relative overflow-hidden min-h-[140px]">
            <div class="w-14 h-14 bg-blue-600 text-white rounded-full flex items-center justify-center text-2xl shadow-lg shrink-0 z-10">
                <i class="fas fa-robot animate-bounce"></i>
            </div>
            <div class="z-10 w-full">
                <p class="text-[11px] font-black text-blue-600 uppercase tracking-widest mb-1">AI Assistant Advisor</p>
                <div id="aiMessage" class="text-lg font-black text-slate-800 transition-all duration-500 w-full">আপনার আজকের ডেটা বিশ্লেষণ করা হচ্ছে...</div>
            </div>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8" id="topSummaryDashboard">
            <div class="dash-card border-b-4 border-b-emerald-400">
                <div class="w-10 h-10 mx-auto bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center mb-3 text-lg"><i class="fas fa-check-double"></i></div>
                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">কাজ সম্পন্ন</p>
                <p id="statTasks" class="text-2xl font-black text-slate-800">০ টি</p>
            </div>
            
            <div class="dash-card border-b-4 border-b-blue-400">
                <div class="w-10 h-10 mx-auto bg-blue-50 text-blue-500 rounded-full flex items-center justify-center mb-3 text-lg"><i class="fas fa-wallet"></i></div>
                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">আজকের খরচ</p>
                <p id="statTodayExp" class="text-2xl font-black text-slate-800">৳০</p>
            </div>

            <div class="dash-card border-b-4 border-b-purple-400">
                <div class="w-10 h-10 mx-auto bg-purple-50 text-purple-500 rounded-full flex items-center justify-center mb-3 text-lg"><i class="fas fa-chart-line"></i></div>
                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">মাসিক খরচ</p>
                <p id="statMonthlyExp" class="text-2xl font-black text-slate-800">৳০</p>
            </div>

            <div class="dash-card border-b-4 border-b-orange-400">
                <div class="w-10 h-10 mx-auto bg-orange-50 text-orange-500 rounded-full flex items-center justify-center mb-3 text-lg"><i class="fas fa-walking"></i></div>
                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">রুটিন পালন</p>
                <p id="statRoutine" class="text-2xl font-black text-slate-800">০%</p>
            </div>

            <div class="dash-card border-b-4 border-b-indigo-400">
                <div class="w-10 h-10 mx-auto bg-indigo-50 text-indigo-500 rounded-full flex items-center justify-center mb-3 text-lg"><i class="fas fa-bed"></i></div>
                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">মোট ঘুম</p>
                <p id="statSleep" class="text-2xl font-black text-slate-800">০ ঘণ্টা</p>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div class="card p-5 border-l-4 border-l-yellow-400 shadow-sm">
                <h3 class="text-sm font-bold text-slate-500 mb-3 uppercase">আজকের অনুভূতি</h3>
                <div class="flex justify-around">
                    <span onclick="setMood('sad')" id="mood-sad" class="mood-btn">😢</span>
                    <span onclick="setMood('neutral')" id="mood-neutral" class="mood-btn">😐</span>
                    <span onclick="setMood('happy')" id="mood-happy" class="mood-btn">😊</span>
                    <span onclick="setMood('amazing')" id="mood-amazing" class="mood-btn">🔥</span>
                </div>
            </div>
            <div class="card p-5 border-l-4 border-l-blue-400 flex flex-col justify-center shadow-sm">
                <div class="flex justify-between items-center mb-2">
                    <h3 class="text-sm font-bold text-slate-500 uppercase">পানি পান</h3>
                    <span id="water-count" class="font-bold text-blue-600 text-lg">০/৮</span>
                </div>
                <div class="flex gap-2">
                    <button onclick="addWater()" class="bg-blue-50 text-blue-600 w-10 h-10 rounded-xl hover:bg-blue-100"><i class="fas fa-glass-water"></i></button>
                    <button onclick="resetWater()" class="text-[10px] text-slate-400 font-bold px-2 py-1 bg-slate-100 rounded-lg hover:bg-slate-200">রিসেট</button>
                </div>
            </div>
            <div class="card p-5 border-l-4 border-l-green-400 flex flex-col justify-center shadow-sm">
                <div class="flex justify-between mb-2 text-xs font-bold text-slate-500 uppercase"><span>সামগ্রিক অগ্রগতি</span><span id="progress-text">০%</span></div>
                <div class="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div id="progress-bar" class="bg-green-500 h-full transition-all duration-500" style="width: 0%"></div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-12 gap-6">
            <div id="mainContentArea" class="md:col-span-8 space-y-6">
                <div data-id="tasks" class="card p-6 border-t-4 border-t-green-500 shadow-sm">
                    <div class="flex justify-between items-start mb-4">
                        <h3 class="font-bold text-lg text-green-600"><i class="fas fa-calendar-day mr-2"></i> আজকের কাজ</h3>
                        <div class="drag-handle"><i class="fas fa-grip-lines text-xl"></i></div>
                    </div>
                    <div class="flex gap-2 mb-4">
                        <input type="text" id="taskInput" placeholder="কি কি করবেন?" class="flex-1 p-3 rounded-xl bg-slate-50 border outline-none text-sm font-bold">
                        <input type="time" id="taskTime" class="p-3 w-32 rounded-xl bg-slate-50 border outline-none text-sm font-bold text-slate-500" title="সময় নির্ধারণ করুন">
                        <button onclick="addTask()" class="bg-green-600 text-white px-5 rounded-xl font-bold hover:bg-green-700 transition">যোগ</button>
                    </div>
                    <ul id="taskList" class="space-y-2"></ul>
                </div>

                <div data-id="goals" class="card p-6 border-t-4 border-t-blue-500 shadow-sm">
                    <div class="flex justify-between items-start mb-4">
                        <h3 class="font-bold text-lg text-blue-600"><i class="fas fa-bullseye mr-2"></i> আমার লক্ষ্য</h3>
                        <div class="drag-handle"><i class="fas fa-grip-lines text-xl"></i></div>
                    </div>
                    <div class="flex flex-col md:flex-row gap-2 mb-4">
                        <input type="text" id="goalInput" placeholder="লক্ষ্যের নাম..." class="flex-1 p-3 rounded-xl bg-slate-50 border outline-none text-sm font-bold">
                        <input type="datetime-local" id="goalDate" class="p-3 rounded-xl bg-slate-50 border outline-none text-sm font-bold text-slate-500">
                        <button onclick="addGoal()" class="bg-blue-600 text-white px-5 py-3 rounded-xl font-bold">সেট</button>
                    </div>
                    <div id="goalList" class="space-y-3"></div>
                </div>

                <div data-id="accounts" class="card p-6 border-t-4 border-t-indigo-500 shadow-sm">
                    <div class="flex justify-between items-start mb-4">
                        <h3 class="font-bold text-lg text-indigo-600"><i class="fas fa-hand-holding-usd mr-2"></i> পাওনা ও দেনা</h3>
                        <div class="drag-handle"><i class="fas fa-grip-lines text-xl"></i></div>
                    </div>
                    <div class="flex gap-2 mb-4">
                        <input type="text" id="personNameInput" placeholder="ব্যক্তির নাম..." class="flex-1 p-3 rounded-xl bg-slate-50 border outline-none text-sm font-bold">
                        <button onclick="addPerson()" class="bg-indigo-600 text-white px-5 rounded-xl font-bold text-xs uppercase hover:bg-indigo-700">নতুন ব্যক্তি</button>
                    </div>
                    <div id="personContainer" class="grid grid-cols-2 md:grid-cols-4 gap-3"></div>
                </div>

                <div data-id="perm-notes" class="card p-6 border-t-4 border-t-pink-500 shadow-sm">
                    <div class="flex justify-between items-start mb-4">
                        <h3 class="font-bold text-lg text-pink-600"><i class="fas fa-infinity mr-2"></i> স্থায়ী নোট</h3>
                        <div class="drag-handle"><i class="fas fa-grip-lines text-xl"></i></div>
                    </div>
                    <div class="mb-4 relative"><i class="fas fa-search absolute left-4 top-3.5 text-slate-400"></i><input type="text" id="permSearch" oninput="renderPermNotes()" placeholder="নোট খুঁজুন..." class="w-full pl-11 pr-4 py-3 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-pink-200 outline-none text-sm font-bold transition"></div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 bg-pink-50/50 p-4 rounded-3xl border border-pink-100">
                        <div class="space-y-3">
                            <input type="text" id="permNoteTitle" placeholder="শিরোনাম..." class="w-full p-3 rounded-xl bg-white border outline-none text-sm font-bold">
                            <button onclick="addPermanentNote()" class="bg-pink-600 text-white px-6 py-3 rounded-xl font-bold text-sm w-full shadow-lg hover:bg-pink-700">সংরক্ষণ</button>
                        </div>
                        <textarea id="permNoteDesc" class="w-full h-24 p-3 bg-white rounded-xl outline-none border text-sm" placeholder="বিস্তারিত..."></textarea>
                    </div>
                    <div id="permNoteList" class="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-80 overflow-y-auto custom-scroll pr-2"></div>
                </div>

                <div data-id="diary" class="card p-6 border-t-4 border-t-purple-500 shadow-sm">
                    <div class="flex justify-between items-start mb-4">
                        <div class="flex items-center gap-3">
                            <h3 class="font-bold text-lg text-purple-600"><i class="fas fa-feather mr-2"></i> প্রতিদিনের ডায়েরি</h3>
                            <span id="saveStatus" class="text-[10px] font-bold text-slate-400 opacity-0 transition-opacity uppercase bg-slate-100 px-2 py-1 rounded">সংরক্ষিত</span>
                        </div>
                        <div class="drag-handle"><i class="fas fa-grip-lines text-xl"></i></div>
                    </div>
                    <div class="flex items-center justify-between mb-4 gap-4">
                        <div id="noteTabs" class="flex gap-2 overflow-x-auto pb-3 pt-1 custom-scroll flex-1"></div>
                        <button onclick="addNewNote()" class="bg-purple-600 hover:bg-purple-700 text-white w-10 h-10 rounded-xl shadow-lg transition"><i class="fas fa-plus"></i></button>
                    </div>
                    <textarea id="noteContent" oninput="handleNoteInput()" class="w-full h-64 p-6 bg-slate-50/50 rounded-3xl outline-none border text-sm font-semibold leading-relaxed" placeholder="আজকের ডায়েরি..."></textarea>
                </div>
            </div>

            <div id="sidebarArea" class="md:col-span-4 space-y-6">
                
                <div class="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-[32px] p-6 mb-8 shadow-sm border border-emerald-100 flex items-center gap-5 relative overflow-hidden">
                    <div class="w-14 h-14 bg-emerald-500 text-white rounded-2xl flex items-center justify-center text-2xl shadow-lg shadow-emerald-200 shrink-0 z-10">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <div class="z-10 w-full">
                        <div class="flex items-center gap-2 mb-1">
                            <span class="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                            <p class="text-[11px] font-black text-emerald-600 uppercase tracking-widest">আজকের বিশেষ সংবাদ</p>
                        </div>
                        <div class="bg-white/60 p-4 rounded-2xl border border-white/50 shadow-sm mt-1 min-h-[60px] flex items-center">
                            <p id="slidingAdvice" class="text-emerald-900 text-sm md:text-base font-bold italic leading-relaxed transition-all duration-700 w-full">
                                "<?php echo htmlspecialchars($all_advices[0]); ?>"
                            </p>
                        </div>
                    </div>
                    <div class="absolute -right-6 -bottom-6 text-emerald-100/50 text-8xl rotate-12">
                        <i class="fas fa-quote-right"></i>
                    </div>
                </div>

                <script>
                    const advices = <?php echo json_encode($all_advices); ?>;
                    let currentIndex = 0;
                    const adviceEl = document.getElementById('slidingAdvice');

                    if(advices.length > 1) {
                        setInterval(() => {
                            adviceEl.style.opacity = 0;
                            adviceEl.style.transform = "translateY(-10px)";
                            setTimeout(() => {
                                currentIndex = (currentIndex + 1) % advices.length;
                                adviceEl.innerText = `"${advices[currentIndex]}"`;
                                adviceEl.style.opacity = 1;
                                adviceEl.style.transform = "translateY(0)";
                            }, 700);
                        }, 7000);
                    }
                </script>
                
                <div data-id="namaz" class="card p-6 border-t-4 border-t-emerald-400 shadow-sm">
                    <div class="flex justify-between items-start mb-4">
                        <h3 class="font-bold text-emerald-600 text-sm uppercase tracking-wider"><i class="fas fa-mosque mr-2"></i> নামাজ ট্র্যাকার</h3>
                        <div class="drag-handle"><i class="fas fa-grip-lines text-xl"></i></div>
                    </div>
                    <div class="grid grid-cols-1 gap-3" id="namazContainer">
                        <label id="lbl-fajr" class="flex items-center justify-between p-4 rounded-2xl cursor-pointer transition-all duration-300 bg-white border-2 border-slate-200 hover:border-emerald-300" onclick="toggleNamaz('fajr')">
                            <div class="flex items-center gap-4">
                                <div id="icon-fajr" class="w-10 h-10 rounded-full flex items-center justify-center transition-colors bg-slate-100 text-slate-500"><i class="fas fa-cloud-sun text-lg"></i></div>
                                <span id="title-fajr" class="font-bold text-lg transition-colors text-slate-700">ফজর</span>
                            </div>
                            <div id="check-fajr" class="w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors border-slate-300 bg-transparent"><i class="fas fa-check text-white text-xs opacity-0 transition-opacity"></i></div>
                        </label>
                        <label id="lbl-dhuhr" class="flex items-center justify-between p-4 rounded-2xl cursor-pointer transition-all duration-300 bg-white border-2 border-slate-200 hover:border-emerald-300" onclick="toggleNamaz('dhuhr')">
                            <div class="flex items-center gap-4">
                                <div id="icon-dhuhr" class="w-10 h-10 rounded-full flex items-center justify-center transition-colors bg-slate-100 text-slate-500"><i class="fas fa-sun text-lg"></i></div>
                                <span id="title-dhuhr" class="font-bold text-lg transition-colors text-slate-700">যোহর</span>
                            </div>
                            <div id="check-dhuhr" class="w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors border-slate-300 bg-transparent"><i class="fas fa-check text-white text-xs opacity-0 transition-opacity"></i></div>
                        </label>
                        <label id="lbl-asr" class="flex items-center justify-between p-4 rounded-2xl cursor-pointer transition-all duration-300 bg-white border-2 border-slate-200 hover:border-emerald-300" onclick="toggleNamaz('asr')">
                            <div class="flex items-center gap-4">
                                <div id="icon-asr" class="w-10 h-10 rounded-full flex items-center justify-center transition-colors bg-slate-100 text-slate-500"><i class="fas fa-sun text-lg"></i></div>
                                <span id="title-asr" class="font-bold text-lg transition-colors text-slate-700">আসর</span>
                            </div>
                            <div id="check-asr" class="w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors border-slate-300 bg-transparent"><i class="fas fa-check text-white text-xs opacity-0 transition-opacity"></i></div>
                        </label>
                        <label id="lbl-maghrib" class="flex items-center justify-between p-4 rounded-2xl cursor-pointer transition-all duration-300 bg-white border-2 border-slate-200 hover:border-emerald-300" onclick="toggleNamaz('maghrib')">
                            <div class="flex items-center gap-4">
                                <div id="icon-maghrib" class="w-10 h-10 rounded-full flex items-center justify-center transition-colors bg-slate-100 text-slate-500"><i class="fas fa-cloud-moon text-lg"></i></div>
                                <span id="title-maghrib" class="font-bold text-lg transition-colors text-slate-700">মাগরিব</span>
                            </div>
                            <div id="check-maghrib" class="w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors border-slate-300 bg-transparent"><i class="fas fa-check text-white text-xs opacity-0 transition-opacity"></i></div>
                        </label>
                        <label id="lbl-isha" class="flex items-center justify-between p-4 rounded-2xl cursor-pointer transition-all duration-300 bg-white border-2 border-slate-200 hover:border-emerald-300" onclick="toggleNamaz('isha')">
                            <div class="flex items-center gap-4">
                                <div id="icon-isha" class="w-10 h-10 rounded-full flex items-center justify-center transition-colors bg-slate-100 text-slate-500"><i class="fas fa-moon text-lg"></i></div>
                                <span id="title-isha" class="font-bold text-lg transition-colors text-slate-700">এশা</span>
                            </div>
                            <div id="check-isha" class="w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors border-slate-300 bg-transparent"><i class="fas fa-check text-white text-xs opacity-0 transition-opacity"></i></div>
                        </label>
                    </div>
                </div>

                <div data-id="expense" class="card p-6 border-t-4 border-t-teal-500 shadow-sm">
                    <div class="flex justify-between items-start mb-4">
                        <h3 class="font-bold text-teal-600 uppercase text-[15px] flex items-center gap-2">
                            <i class="fas fa-file-invoice-dollar text-lg"></i> আজকের ব্যয়
                        </h3>
                        <div class="drag-handle"><i class="fas fa-grip-lines text-xl"></i></div>
                    </div>
                    <div class="space-y-2 mb-4">
                        <input type="number" id="expAmount" placeholder="টাকা" class="w-full p-3 rounded-xl bg-slate-50 border text-sm font-bold outline-none">
                        <div class="flex gap-2">
                            <input type="text" id="expNote" placeholder="খাত (কীসে খরচ?)" class="flex-1 p-3 rounded-xl bg-slate-50 border text-sm font-bold outline-none">
                            <button onclick="addExpense()" class="bg-teal-500 hover:bg-teal-600 transition text-white px-5 rounded-xl"><i class="fas fa-plus"></i></button>
                        </div>
                    </div>
                    <ul id="expenseList" class="space-y-2 text-sm max-h-48 overflow-y-auto custom-scroll pr-1"></ul>
                    <div id="expenseSummary" class="mt-4 pt-4 border-t font-bold text-slate-700">
                        <div class="flex justify-between items-center text-lg">
                            <span class="text-xs text-slate-500 uppercase tracking-widest">মোট</span>
                            <span id="totalExpenseDisplay" class="font-black text-teal-600">৳০</span>
                        </div>
                    </div>
                </div>

                <div data-id="routine" class="card p-6 border-t-4 border-t-orange-500 shadow-sm">
                    <div class="flex justify-between items-start mb-4">
                        <h3 class="font-bold text-orange-600 text-sm uppercase"><i class="fas fa-tasks mr-2"></i> রুটিন</h3>
                        <div class="drag-handle"><i class="fas fa-grip-lines text-xl"></i></div>
                    </div>
                    <div id="habitContainer" class="space-y-2"></div>
                </div>

                <div data-id="quick-note" class="card p-6 border-t-4 border-t-yellow-400 shadow-sm">
                    <div class="flex justify-between items-start mb-4">
                        <h3 class="font-bold text-yellow-600 text-sm uppercase flex items-center gap-2">
                            <i class="fas fa-sticky-note"></i> কুইক নোট
                            <button onclick="addQuickNoteBox()" class="bg-yellow-100 text-yellow-600 hover:bg-yellow-200 w-6 h-6 rounded-full flex items-center justify-center transition ml-2" title="নতুন নোট যোগ করুন"><i class="fas fa-plus text-xs"></i></button>
                        </h3>
                        <div class="drag-handle"><i class="fas fa-grip-lines text-xl"></i></div>
                    </div>
                    <div id="quickNotesContainer" class="space-y-3"></div>
                </div>

                <div data-id="sleep-tracker" class="card p-6 border-t-4 border-t-indigo-400 shadow-sm">
                    <div class="flex justify-between items-start mb-4">
                        <h3 class="font-bold text-indigo-600 text-sm uppercase"><i class="fas fa-bed mr-2"></i> ঘুমের ট্র্যাকার</h3>
                        <div class="drag-handle"><i class="fas fa-grip-lines text-xl"></i></div>
                    </div>
                    <div class="grid grid-cols-2 gap-3 mb-3">
                        <div>
                            <label class="text-[10px] font-bold text-slate-400 uppercase">ঘুমানোর সময়</label>
                            <input type="time" id="sleepStartInput" onchange="calculateSleepTime()" class="w-full p-2 mt-1 rounded-xl bg-slate-50 border outline-none font-bold text-sm focus:border-indigo-300 transition">
                        </div>
                        <div>
                            <label class="text-[10px] font-bold text-slate-400 uppercase">ওঠার সময়</label>
                            <input type="time" id="sleepEndInput" onchange="calculateSleepTime()" class="w-full p-2 mt-1 rounded-xl bg-slate-50 border outline-none font-bold text-sm focus:border-indigo-300 transition">
                        </div>
                    </div>
                    <div class="bg-indigo-50 border border-indigo-100 p-3 rounded-xl flex items-center justify-between mt-2">
                        <span class="font-bold text-indigo-800 text-xs">মোট ঘুম:</span>
                        <span class="text-sm font-black text-indigo-600"><span id="sleepDisplay">০</span> ঘণ্টা</span>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <div id="profileModal" class="hidden fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
        <div class="bg-white w-full max-w-lg rounded-[32px] p-8 max-h-[90vh] overflow-y-auto modal-animate shadow-2xl no-scrollbar">
            <div class="flex justify-between items-center mb-6">
                <div>
                    <h2 class="text-2xl font-black text-slate-800">প্রোফাইল আপডেট</h2>
                    <p class="text-xs font-bold text-slate-400 uppercase">আপনার তথ্য পরিবর্তন করুন</p>
                </div>
                <button onclick="toggleProfile()" class="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 hover:text-red-500">
                    <i class="fa-solid fa-times text-xl"></i>
                </button>
            </div>

            <form action="auth.php?action=update_profile" method="POST" class="space-y-4">
                <input type="hidden" name="email" value="<?php echo $u['email']; ?>">
                
                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-500 ml-1">পূর্ণ নাম</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($u['name']); ?>" required class="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-blue-500 transition">
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div class="space-y-1">
                        <label class="text-xs font-bold text-slate-500 ml-1">মোবাইল</label>
                        <input type="text" name="mobile" value="<?php echo htmlspecialchars($u['mobile']); ?>" class="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none">
                    </div>
                    <div class="space-y-1">
                        <label class="text-xs font-bold text-slate-500 ml-1">রক্তের গ্রুপ</label>
                        <select name="blood_group" class="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none">
                            <option value="">নির্বাচন করুন</option>
                            <?php 
                            $groups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
                            foreach($groups as $g) {
                                $selected = ($u['blood_group'] == $g) ? 'selected' : '';
                                echo "<option value='$g' $selected>$g</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-500 ml-1">শিক্ষা প্রতিষ্ঠান</label>
                    <input type="text" name="institution" value="<?php echo htmlspecialchars($u['institution'] ?? ''); ?>" placeholder="স্কুল/কলেজ/বিশ্ববিদ্যালয়" class="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-blue-500 transition">
                </div>

                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-500 ml-1">শখ</label>
                    <input type="text" name="hobby" value="<?php echo htmlspecialchars($u['hobby'] ?? ''); ?>" placeholder="যেমন: কোডিং, বাগান করা" class="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-blue-500 transition">
                </div>

                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-500 ml-1">জন্ম তারিখ</label>
                    <input type="date" name="dob" value="<?php echo $u['dob']; ?>" class="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none">
                </div>

                <div class="space-y-1">
                    <label class="text-xs font-bold text-slate-500 ml-1">ঠিকানা</label>
                    <textarea name="address" class="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-blue-500 transition h-20"><?php echo htmlspecialchars($u['address']); ?></textarea>
                </div>

                <div class="pt-4 flex flex-col gap-2">
                    <button type="submit" class="w-full bg-blue-600 text-white py-4 rounded-2xl font-black shadow-lg hover:bg-blue-700 transition active:scale-95">
                        পরিবর্তন সেভ করুন
                    </button>
                    <a href="auth.php?action=logout" class="text-center text-red-500 font-bold py-2 hover:underline">লগআউট</a>
                </div>
            </form>
        </div>
    </div>

    <div id="infoModal" class="modal-overlay">
        <div class="modal-box bg-white rounded-[32px] w-full max-w-sm p-8 shadow-2xl text-center">
            <div class="w-20 h-20 bg-blue-50 text-blue-500 rounded-full flex items-center justify-center mx-auto mb-6 text-4xl">
                <i class="fas fa-info-circle"></i>
            </div>
            <h3 class="text-xl font-black text-slate-800 mb-2">নোটিশ</h3>
            <p id="infoModalText" class="text-slate-500 text-sm mb-8">...</p>
            <button onclick="closeInfoModal()" class="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold shadow-lg">ঠিক আছে</button>
        </div>
    </div>

    <div id="confirmModal" class="modal-overlay">
        <div class="modal-box bg-white rounded-[32px] w-full max-w-sm p-8 shadow-2xl text-center">
            <div class="w-20 h-20 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto mb-6 text-4xl"><i class="fas fa-exclamation-triangle"></i></div>
            <h3 class="text-xl font-black text-slate-800 mb-2">আপনি কি নিশ্চিত?</h3>
            <p class="text-slate-500 text-sm mb-8">এটি ডিলিট করলে আর ফিরে পাওয়া যাবে না।</p>
            <div class="flex gap-3">
                <button onclick="closeConfirmModal()" class="flex-1 bg-slate-100 text-slate-600 py-4 rounded-2xl font-bold">বাতিল</button>
                <button id="confirmDeleteBtn" class="flex-1 bg-red-500 text-white py-4 rounded-2xl font-bold shadow-lg hover:bg-red-600">ডিলিট</button>
            </div>
        </div>
    </div>

    <div id="settingsModal" class="modal-overlay">
        <div class="modal-box bg-white rounded-[32px] w-full max-w-lg p-8 shadow-2xl max-h-[90vh] overflow-y-auto no-scrollbar">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-2xl font-black text-slate-800"><i class="fas fa-cog mr-2"></i> সেটিংস</h3>
                <button onclick="closeSettings()"><i class="fas fa-times-circle text-3xl text-slate-300 hover:text-red-500 transition"></i></button>
            </div>
            <div class="space-y-8">
                <section>
                    <h4 class="font-bold text-emerald-600 border-b pb-2 mb-4 text-xs uppercase tracking-widest">নামাজের সময়</h4>
                    <div class="grid grid-cols-2 gap-4">
                        <div><label class="text-xs font-bold text-slate-400">ফজর</label><input type="time" id="set-fajr" class="w-full p-2 border rounded-xl font-bold"></div>
                        <div><label class="text-xs font-bold text-slate-400">যোহর</label><input type="time" id="set-dhuhr" class="w-full p-2 border rounded-xl font-bold"></div>
                        <div><label class="text-xs font-bold text-slate-400">আসর</label><input type="time" id="set-asr" class="w-full p-2 border rounded-xl font-bold"></div>
                        <div><label class="text-xs font-bold text-slate-400">মাগরিব</label><input type="time" id="set-maghrib" class="w-full p-2 border rounded-xl font-bold"></div>
                        <div class="col-span-2"><label class="text-xs font-bold text-slate-400">এশা</label><input type="time" id="set-isha" class="w-full p-2 border rounded-xl font-bold"></div>
                    </div>
                </section>
                <section>
                    <h4 class="font-bold text-blue-600 border-b pb-2 mb-4 text-xs uppercase tracking-widest">বাজেট ও ঘুম</h4>
                    <div class="grid grid-cols-2 gap-4 mb-4">
                        <div><label class="text-xs font-bold text-slate-400">ডেইলি বাজেট</label><input type="number" id="set-daily-budget" class="w-full p-2 border rounded-xl font-bold" placeholder="যেমন: ৫০০"></div>
                        <div><label class="text-xs font-bold text-slate-400">মাসিক বাজেট</label><input type="number" id="set-monthly-budget" class="w-full p-2 border rounded-xl font-bold" placeholder="যেমন: ১৫০০০"></div>
                        <div class="col-span-2"><label class="text-xs font-bold text-slate-400">ঘুমানোর রুটিন (Bedtime)</label><input type="time" id="set-bedtime" class="w-full p-2 border rounded-xl font-bold"></div>
                    </div>
                </section>
                <section>
                    <h4 class="font-bold text-orange-600 border-b pb-2 mb-4 text-xs uppercase tracking-widest">রুটিন ম্যানেজমেন্ট</h4>
                    <div class="flex gap-2 mb-4">
                        <input type="text" id="habitInputS" placeholder="নতুন রুটিন..." class="flex-1 p-3 rounded-xl bg-slate-50 border outline-none font-bold text-sm">
                        <button onclick="addNewHabit()" class="bg-orange-500 hover:bg-orange-600 transition text-white px-6 rounded-xl font-bold">যোগ</button>
                    </div>
                    <div id="settingsHabitList" class="space-y-2 max-h-40 overflow-y-auto custom-scroll"></div>
                </section>
                <button onclick="saveAllSettings()" class="w-full bg-blue-600 text-white py-4 rounded-2xl font-black shadow-lg hover:bg-blue-700 transition">সংরক্ষণ করুন</button>
            </div>
        </div>
    </div>

    <div id="permNoteModal" class="modal-overlay">
        <div class="modal-box bg-white rounded-[32px] w-full max-w-lg p-8 shadow-2xl">
            <div class="flex justify-between items-start mb-6">
                <h3 id="pNoteViewTitle" class="text-2xl font-black text-slate-800">শিরোনাম</h3>
                <button onclick="closePNoteModal()"><i class="fas fa-times-circle text-3xl text-slate-300"></i></button>
            </div>
            <div id="pNoteViewContent" class="text-slate-600 whitespace-pre-wrap max-h-96 overflow-y-auto custom-scroll pr-2 leading-relaxed"></div>
        </div>
    </div>

    <div id="accModal" class="modal-overlay">
        <div class="modal-box bg-white rounded-[32px] w-full max-w-md p-6 shadow-2xl">
            <div class="flex justify-between items-center mb-4">
                <h3 id="modalName" class="text-xl font-bold">ব্যক্তি</h3>
                <button onclick="closeModal()"><i class="fas fa-times-circle text-2xl text-slate-300"></i></button>
            </div>
            <div class="grid grid-cols-2 gap-3 mb-4">
                <div class="bg-green-50 p-3 rounded-2xl text-center"><p class="text-[10px] font-bold text-green-600 uppercase">পাওনা</p><p id="modalPawa" class="text-lg font-black text-green-700">৳০</p></div>
                <div class="bg-red-50 p-3 rounded-2xl text-center"><p class="text-[10px] font-bold text-red-600 uppercase">দেনা</p><p id="modalDena" class="text-lg font-black text-red-700">৳০</p></div>
            </div>
            <div class="space-y-2 mb-4">
                <input type="number" id="tAmount" placeholder="টাকা" class="w-full p-3 border rounded-xl font-bold outline-none">
                <input type="text" id="tNote" placeholder="বিবরণ" class="w-full p-3 border rounded-xl font-bold outline-none">
                <div class="flex gap-2">
                    <button onclick="addTrans('pawa')" class="flex-1 bg-green-600 text-white py-3 rounded-xl font-bold">পাওনা (+)</button>
                    <button onclick="addTrans('dena')" class="flex-1 bg-red-600 text-white py-3 rounded-xl font-bold">দেনা (-)</button>
                </div>
            </div>
            <div id="modalList" class="space-y-2 max-h-48 overflow-y-auto custom-scroll"></div>
        </div>
    </div>

    <script>
        const userEmail = localStorage.getItem('currentUserEmail') || "<?php echo $user_email; ?>";
        const todayStr = new Date().toISOString().split('T')[0];
        let currentLoadedDate = todayStr;
        let mood = '', water = 0, accounts = {}, habits = [], notebooks = [], activeNoteId = 0, namaz = {}, permNotes = [], goals = [];
        let namazTimes = { fajr: "05:30", dhuhr: "13:30", asr: "16:45", maghrib: "18:20", isha: "20:00" };
        let activePerson = null;

        let extraSettings = JSON.parse(localStorage.getItem(`extra_settings_${userEmail}`)) || { dailyLimit: 500, monthlyLimit: 15000, sleepTime: "22:00" };

        let quickNotesArray = [""];
        let sleepStart = "", sleepEnd = "", sleepHours = 0;

        let activeAIInsights = [];
        let currentInsightIndex = 0;

        function openInfoModal(text) { document.getElementById('infoModalText').innerText = text; document.getElementById('infoModal').classList.add('active'); }
        function closeInfoModal() { document.getElementById('infoModal').classList.remove('active'); }

        let confirmAction = null;
        function openConfirmModal(callback) { confirmAction = callback; document.getElementById('confirmModal').classList.add('active'); }
        function closeConfirmModal() { document.getElementById('confirmModal').classList.remove('active'); confirmAction = null; }
        document.getElementById('confirmDeleteBtn').onclick = () => { if (confirmAction) confirmAction(); closeConfirmModal(); };

        function toggleProfile() {
            const modal = document.getElementById('profileModal');
            if (modal.classList.contains('hidden')) { modal.classList.remove('hidden'); } 
            else { modal.classList.add('hidden'); }
        }

        function toggleUserMenu() { document.getElementById('userMenu').classList.toggle('show'); }

        window.onclick = function(event) {
            if (!event.target.closest('.user-dropdown')) {
                const userMenu = document.getElementById('userMenu');
                if (userMenu) userMenu.classList.remove('show');
            }
            const profileModal = document.getElementById('profileModal');
            if (event.target == profileModal) { profileModal.classList.add('hidden'); }
        }

        window.onload = () => { 
            const userName = localStorage.getItem('currentUserName') || 'User';
            document.getElementById('pillName').innerText = userName;
            const dInput = document.getElementById('historyDate');
            dInput.max = todayStr; dInput.value = todayStr;
            
            goals = JSON.parse(localStorage.getItem(`goals_${userEmail}`)) || [];
            const savedTimes = localStorage.getItem(`namaz_times_${userEmail}`);
            if(savedTimes) namazTimes = JSON.parse(savedTimes);
            
            loadData(todayStr); 
            initSortable();
            setInterval(checkTaskTimes, 1000); // Check Task Times every second
            setInterval(buildAIInsights, 60000); // Rebuild insights every minute
            setInterval(rotateAIInsights, 5000); // Rotate insights every 5 seconds
            setInterval(updateGoalTimers, 1000);
        };

        async function loadData(date) {
            const res = await fetch(`db_handler.php?action=load&email=${userEmail}&date=${date}`);
            const data = await res.json();
            if((!data || Object.keys(data).length === 0) && date !== todayStr) {
                openInfoModal(`${date} তারিখের জন্য কোন তথ্য পাওয়া যায়নি।`);
                document.getElementById('historyDate').value = currentLoadedDate;
                return;
            }
            currentLoadedDate = date;
            permNotes = JSON.parse(localStorage.getItem(`perm_notes_list_${userEmail}`)) || [];
            if(!data || Object.keys(data).length === 0) { if(date === todayStr) { await carryOverHabits(); renderAll(); } return; }
            mood = data.mood || ''; water = data.water || 0; accounts = data.accounts || {};
            habits = data.habits || []; notebooks = data.notebooks || [{id: 1, title: 'নোট ১', content: ''}];
            activeNoteId = data.activeNoteId || (notebooks[0] ? notebooks[0].id : 1);
            namaz = data.namaz || {};
            
            if(data.quickNotesArray) { quickNotesArray = data.quickNotesArray; } 
            else if (data.quickNote) { quickNotesArray = [data.quickNote]; } 
            else { quickNotesArray = [""]; }

            sleepStart = data.sleepStart || "";
            sleepEnd = data.sleepEnd || "";
            sleepHours = data.sleepHours || 0;
            
            document.getElementById('sleepStartInput').value = sleepStart;
            document.getElementById('sleepEndInput').value = sleepEnd;
            document.getElementById('sleepDisplay').innerText = sleepHours > 0 ? sleepHours : '০';

            renderTasks(data.tasks || []); renderExpenses(data.expenses || []); renderAll();
            updateSummaryCards(); 
            buildAIInsights();
        }

        function applyDateFilter() { const selectedDate = document.getElementById('historyDate').value; if(selectedDate) loadData(selectedDate); }

        async function carryOverHabits() {
            const yest = new Date(); yest.setDate(yest.getDate() - 1);
            const res = await fetch(`db_handler.php?action=load&email=${userEmail}&date=${yest.toISOString().split('T')[0]}`);
            const old = await res.json();
            habits = (old && old.habits) ? old.habits.map(h => ({...h, checked: false})) : [];
        }

        function updateSummaryCards() {
            const taskBoxes = document.querySelectorAll('#taskList input[type="checkbox"]');
            let tasksDone = 0;
            taskBoxes.forEach(box => { if(box.checked) tasksDone++; });
            document.getElementById('statTasks').innerText = `${tasksDone} টি`;

            let todayExp = 0;
            document.querySelectorAll('.exp-amt').forEach(s => todayExp += parseInt(s.innerText.replace('৳', '')) || 0);
            document.getElementById('statTodayExp').innerText = `৳${todayExp}`;

            let baseMonthly = parseInt(localStorage.getItem(`mock_monthly_exp_${userEmail}`)) || 0; 
            document.getElementById('statMonthlyExp').innerText = `৳${baseMonthly + todayExp}`;

            let totalHabits = habits.length;
            let habitsDone = habits.filter(h => h.checked).length;
            let routinePerc = totalHabits > 0 ? Math.round((habitsDone / totalHabits) * 100) : 0;
            document.getElementById('statRoutine').innerText = `${routinePerc}%`;

            document.getElementById('statSleep').innerText = `${sleepHours > 0 ? sleepHours : '০'} ঘণ্টা`;
        }

        function addGoal() {
            const t = document.getElementById('goalInput').value, d = document.getElementById('goalDate').value;
            if(!t || !d) return;
            goals.unshift({ id: Date.now(), title: t, target: d });
            localStorage.setItem(`goals_${userEmail}`, JSON.stringify(goals));
            document.getElementById('goalInput').value = ''; document.getElementById('goalDate').value = '';
            renderGoals(); buildAIInsights();
        }
        function renderGoals() {
            document.getElementById('goalList').innerHTML = goals.map(g => `
                <div class="flex justify-between items-center p-4 bg-slate-50 rounded-2xl border">
                    <div><h4 class="font-bold text-sm text-slate-700">${g.title}</h4><div id="timer-${g.id}" class="goal-timer text-blue-600 font-bold mt-1">হিসাব করা হচ্ছে...</div></div>
                    <button onclick="openConfirmModal(() => deleteGoal(${g.id}))" class="text-red-300 hover:text-red-500 transition"><i class="fas fa-trash"></i></button>
                </div>`).join('');
            updateGoalTimers();
        }
        function updateGoalTimers() {
            const now = new Date().getTime();
            goals.forEach(g => {
                const target = new Date(g.target).getTime();
                const diff = target - now;
                const el = document.getElementById(`timer-${g.id}`);
                if (!el) return;
                if (diff < 0) { el.innerHTML = "<span class='text-red-500'>সময় শেষ!</span>"; return; }
                const d = Math.floor(diff / (1000 * 60 * 60 * 24)), 
                      h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)), 
                      m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)), 
                      s = Math.floor((diff % (1000 * 60)) / 1000);
                el.innerText = `${d} দিন ${h} ঘণ্টা ${m} মি. ${s} সে. বাকি`;
            });
        }
        function deleteGoal(id) { goals = goals.filter(g => g.id !== id); localStorage.setItem(`goals_${userEmail}`, JSON.stringify(goals)); renderGoals(); }

        function addTask() { 
            const v = document.getElementById('taskInput').value; 
            const tm = document.getElementById('taskTime').value;
            if(v){ 
                const id = Date.now();
                const li = document.createElement('li'); li.id = `task-${id}`;
                li.setAttribute('data-time', tm);
                li.className = "flex justify-between items-center p-3 bg-slate-50 rounded-xl border group transition-colors duration-300"; 
                li.innerHTML = `<div class="flex items-center gap-3"><input type="checkbox" onchange="updateProgress(); saveData(); updateSummaryCards(); buildAIInsights();" class="w-5 h-5 accent-green-600 rounded"><span class="task-text text-sm font-bold text-slate-700">${v}</span> <span class="text-[10px] text-slate-400 font-bold bg-white px-2 py-1 rounded">${tm ? tm : 'সময় নাই'}</span></div>
                    <button onclick="openConfirmModal(() => { document.getElementById('task-${id}').remove(); updateProgress(); saveData(); updateSummaryCards(); buildAIInsights(); })" class="w-8 h-8 flex items-center justify-center text-red-300 hover:text-white hover:bg-red-500 rounded-lg transition opacity-0 group-hover:opacity-100"><i class="fas fa-trash"></i></button>`; 
                document.getElementById('taskList').prepend(li); 
                document.getElementById('taskInput').value = ''; document.getElementById('taskTime').value = '';
                updateProgress(); saveData(); updateSummaryCards(); buildAIInsights();
            } 
        }
        function renderTasks(ts) { 
            document.getElementById('taskList').innerHTML = ts.map((t, i) => {
                const id = "task-old-" + i;
                const tm = t.time || '';
                return `<li id="${id}" data-time="${tm}" class="flex justify-between items-center p-3 bg-slate-50 rounded-xl border group transition-colors duration-300">
                    <div class="flex items-center gap-3"><input type="checkbox" onchange="updateProgress(); saveData(); updateSummaryCards(); buildAIInsights();" ${t.done?'checked':''} class="w-5 h-5 accent-green-600 rounded"><span class="task-text text-sm font-bold text-slate-700 ${t.done?'completed':''}">${t.text}</span> <span class="text-[10px] text-slate-400 font-bold bg-white px-2 py-1 rounded">${tm ? tm : 'সময় নাই'}</span></div>
                    <button onclick="openConfirmModal(() => { document.getElementById('${id}').remove(); updateProgress(); saveData(); updateSummaryCards(); buildAIInsights(); })" class="w-8 h-8 flex items-center justify-center text-red-300 hover:text-white hover:bg-red-500 rounded-lg transition opacity-0 group-hover:opacity-100"><i class="fas fa-trash"></i></button>
                </li>`
            }).join(''); 
        }

        // টাস্ক অ্যালার্ট চেক লজিক
        function checkTaskTimes() {
            if (currentLoadedDate !== todayStr) return;
            const now = new Date();
            const currentMs = now.getTime();
            
            document.querySelectorAll('#taskList li').forEach(li => {
                if(li.querySelector('input').checked) {
                    li.classList.remove('task-warning', 'task-danger');
                    return;
                }
                const timeStr = li.getAttribute('data-time');
                if(!timeStr) return;
                
                const [h, m] = timeStr.split(':').map(Number);
                const taskTime = new Date();
                taskTime.setHours(h, m, 0, 0);
                
                const diff = taskTime.getTime() - currentMs;
                
                if(diff <= 0) {
                    li.classList.remove('task-warning');
                    li.classList.add('task-danger');
                } else if(diff <= 180000) { // 3 mins in ms
                    li.classList.remove('task-danger');
                    li.classList.add('task-warning');
                } else {
                    li.classList.remove('task-warning', 'task-danger');
                }
            });
        }

        function renderNotebooks() {
            document.getElementById('noteTabs').innerHTML = notebooks.map(n => `
                <button onclick="activeNoteId=${n.id}; renderNotebooks();" class="diary-tab ${n.id === activeNoteId ? 'active' : ''}">
                    <span>${n.title}</span><i onclick="event.stopPropagation(); openConfirmModal(() => deleteNotebook(${n.id}))" class="fas fa-trash-alt delete-note-btn"></i>
                </button>`).join('');
            const current = notebooks.find(n => n.id === activeNoteId);
            document.getElementById('noteContent').value = current ? current.content : '';
        }
        function addNewNote() { const name = prompt("নোটের নাম:"); if(name) { notebooks.push({ id: Date.now(), title: name, content: '' }); renderNotebooks(); saveData(); } }
        function deleteNotebook(id) { if(notebooks.length > 1) { notebooks = notebooks.filter(n => n.id !== id); if(activeNoteId === id) activeNoteId = notebooks[0].id; renderNotebooks(); saveData(); } }
        function handleNoteInput() { 
            const n = notebooks.find(n => n.id === activeNoteId); 
            if(n) { 
                n.content = document.getElementById('noteContent').value; 
                saveData(); 
                let st = document.getElementById('saveStatus');
                st.style.opacity = 1;
                setTimeout(() => st.style.opacity = 0, 1500);
            } 
        }

        function renderAcc() {
            const c = document.getElementById('personContainer'); c.innerHTML = "";
            for (let n in accounts) {
                let bal = 0; accounts[n].trans.forEach(t => bal += (t.type === 'pawa' ? t.amount : -t.amount));
                let clr = bal > 0 ? "bg-emerald-50 text-emerald-600 border-emerald-100" : (bal < 0 ? "bg-rose-50 text-rose-600 border-rose-100" : "bg-slate-50 text-slate-600 border-slate-100");
                c.innerHTML += `<div onclick="openModal('${n}')" class="acc-card group p-4 border-2 rounded-[14px] text-center cursor-pointer ${clr} transition-all duration-300 hover:shadow-sm relative flex flex-col items-center justify-center min-h-[80px]">
                    <i onclick="event.stopPropagation(); openConfirmModal(() => deletePerson('${n}'))" class="fas fa-times-circle absolute top-2 right-2 opacity-0 group-hover:opacity-100 text-red-300 hover:text-red-500 transition-all text-xs"></i>
                    <div class="font-bold text-sm truncate w-full mb-1">${n}</div><div class="font-black text-base">৳${Math.abs(bal)}</div></div>`;
            }
        }
        function addPerson() { const n = document.getElementById('personNameInput').value.trim(); if(n) { accounts[n] = { trans: [] }; document.getElementById('personNameInput').value = ""; renderAcc(); saveData(); } }
        function deletePerson(n) { delete accounts[n]; renderAcc(); saveData(); }
        function openModal(n) { activePerson = n; document.getElementById('modalName').innerText = n; document.getElementById('accModal').classList.add('active'); renderTransList(); }
        function closeModal() { document.getElementById('accModal').classList.remove('active'); }
        function addTrans(type) { const amt = parseInt(document.getElementById('tAmount').value); if(amt) { accounts[activePerson].trans.push({type, amount: amt, note: document.getElementById('tNote').value || 'লেনদেন'}); renderAcc(); renderTransList(); saveData(); document.getElementById('tAmount').value=''; document.getElementById('tNote').value=''; } }
        function renderTransList() { 
            let p=0, d=0; 
            document.getElementById('modalList').innerHTML = accounts[activePerson].trans.map((t, i) => { 
                if(t.type==='pawa') p+=t.amount; else d+=t.amount; 
                return `<div class="flex justify-between items-center p-2 rounded-lg mb-1 ${t.type==='pawa'?'bg-green-50 text-green-700':'bg-red-50 text-red-700'} text-[10px] font-bold"><span>${t.note} (৳${t.amount})</span><i onclick="openConfirmModal(() => { accounts[activePerson].trans.splice(${i}, 1); renderTransList(); renderAcc(); saveData(); })" class="fas fa-trash-alt opacity-30 cursor-pointer hover:opacity-100 transition"></i></div>`; 
            }).join(''); 
            document.getElementById('modalPawa').innerText = `৳${p}`; document.getElementById('modalDena').innerText = `৳${d}`; 
        }

        function addPermanentNote() {
            const t = document.getElementById('permNoteTitle').value, d = document.getElementById('permNoteDesc').value;
            if(!t || !d) return;
            permNotes.unshift({ id: Date.now(), title: t, desc: d });
            localStorage.setItem(`perm_notes_list_${userEmail}`, JSON.stringify(permNotes));
            document.getElementById('permNoteTitle').value = ''; document.getElementById('permNoteDesc').value = '';
            renderPermNotes();
        }
        function renderPermNotes() {
            const term = document.getElementById('permSearch').value.toLowerCase();
            const filtered = permNotes.filter(n => n.title.toLowerCase().includes(term) || n.desc.toLowerCase().includes(term));
            document.getElementById('permNoteList').innerHTML = filtered.map(n => `<div class="perm-note-card p-4 rounded-2xl border flex justify-between items-start" onclick="viewPNote(${n.id})"><div class="overflow-hidden"><h4 class="font-bold text-sm mb-1">${n.title}</h4><p class="text-[10px] text-slate-400 line-clamp-1">${n.desc}</p></div><button onclick="event.stopPropagation(); openConfirmModal(() => deletePNote(${n.id}))" class="text-red-300 hover:text-red-500 transition"><i class="fas fa-trash-alt text-xs"></i></button></div>`).join('');
        }
        function deletePNote(id) { permNotes = permNotes.filter(n => n.id !== id); localStorage.setItem(`perm_notes_list_${userEmail}`, JSON.stringify(permNotes)); renderPermNotes(); }
        function viewPNote(id) { const n = permNotes.find(n => n.id === id); if(n) { document.getElementById('pNoteViewTitle').innerText = n.title; document.getElementById('pNoteViewContent').innerText = n.desc; document.getElementById('permNoteModal').classList.add('active'); } }
        function closePNoteModal() { document.getElementById('permNoteModal').classList.remove('active'); }

        function addExpense() { 
            const amt = document.getElementById('expAmount').value, note = document.getElementById('expNote').value; 
            if(!amt || !note) return; 
            const id = "exp-" + Date.now();
            const li = document.createElement('li'); li.id = id;
            li.className = "flex justify-between items-center bg-white p-3 border border-slate-100 rounded-xl mb-2 shadow-sm transition-all"; 
            li.innerHTML = `
                <span class="exp-note font-bold text-slate-700">${note}</span>
                <div class="flex items-center gap-3">
                    <span class="text-teal-600 font-black exp-amt">৳${amt}</span>
                    <button class="w-7 h-7 bg-red-50 text-red-400 rounded flex items-center justify-center hover:bg-red-500 hover:text-white transition cursor-pointer" onclick="openConfirmModal(() => { document.getElementById('${id}').remove(); calculateTotal(); saveData(); buildAIInsights(); })">
                        <i class="fas fa-trash-alt text-xs"></i>
                    </button>
                </div>
            `; 
            document.getElementById('expenseList').prepend(li); calculateTotal(); saveData(); buildAIInsights();
            document.getElementById('expAmount').value = ''; document.getElementById('expNote').value = ''; 
        }
        
        function renderExpenses(exps) { 
            document.getElementById('expenseList').innerHTML = exps.map((e, i) => {
                const id = "exp-old-" + i;
                return `
                <li id="${id}" class="flex justify-between items-center bg-white p-3 border border-slate-100 rounded-xl mb-2 shadow-sm transition-all">
                    <span class="exp-note font-bold text-slate-700">${e.note}</span>
                    <div class="flex items-center gap-3">
                        <span class="text-teal-600 font-black exp-amt">৳${e.amt}</span>
                        <button class="w-7 h-7 bg-red-50 text-red-400 rounded flex items-center justify-center hover:bg-red-500 hover:text-white transition cursor-pointer" onclick="openConfirmModal(() => { document.getElementById('${id}').remove(); calculateTotal(); saveData(); buildAIInsights(); })">
                            <i class="fas fa-trash-alt text-xs"></i>
                        </button>
                    </div>
                </li>`
            }).join(''); 
            calculateTotal(); 
        }
        
        async function calculateTotal() { 
            let d = 0; 
            document.querySelectorAll('.exp-amt').forEach(s => d += parseInt(s.innerText.replace('৳', '')) || 0); 
            document.getElementById('totalExpenseDisplay').innerText = `৳${d}`;
            updateSummaryCards();
        }

        function renderQuickNotes() {
            const container = document.getElementById('quickNotesContainer');
            container.innerHTML = quickNotesArray.map((note, index) => `
                <div class="relative group">
                    <textarea oninput="updateQuickNote(${index}, this.value)" class="w-full h-24 p-4 bg-slate-50 border border-slate-100 rounded-xl outline-none resize-none text-sm font-semibold focus:border-yellow-300 transition" placeholder="এখানে কিছু লিখে রাখুন...">${note}</textarea>
                    <button onclick="clearQuickNote(${index})" class="absolute top-3 right-3 text-[10px] font-bold bg-red-100 text-red-500 hover:bg-red-500 hover:text-white px-2 py-1 rounded transition opacity-50 hover:opacity-100 shadow-sm">Clear</button>
                </div>
            `).join('');
        }
        function addQuickNoteBox() { quickNotesArray.push(""); renderQuickNotes(); saveData(); }
        function updateQuickNote(index, val) { quickNotesArray[index] = val; saveData(); }
        function clearQuickNote(index) { quickNotesArray[index] = ""; renderQuickNotes(); saveData(); }

        function calculateSleepTime() {
            sleepStart = document.getElementById('sleepStartInput').value;
            sleepEnd = document.getElementById('sleepEndInput').value;
            
            if(sleepStart && sleepEnd) {
                let d1 = new Date(`2000-01-01T${sleepStart}`);
                let d2 = new Date(`2000-01-01T${sleepEnd}`);
                if(d2 < d1) d2.setDate(d2.getDate() + 1);
                
                let diff = (d2 - d1) / (1000 * 60 * 60);
                sleepHours = diff.toFixed(1); 
            } else {
                sleepHours = 0;
            }
            
            document.getElementById('sleepDisplay').innerText = sleepHours > 0 ? sleepHours : '০';
            updateSummaryCards();
            saveData();
        }

        function renderAll() { setMood(mood); updateWaterUI(); renderAcc(); renderNotebooks(); renderHabits(); renderNamaz(); renderGoals(); updateProgress(); renderPermNotes(); updateSummaryCards(); renderQuickNotes(); }
        
        async function saveData() { 
            if(currentLoadedDate !== todayStr) return; 
            const data = { 
                mood, water, 
                tasks: Array.from(document.querySelectorAll('#taskList li')).map(li => ({ text: li.querySelector('.task-text').innerText, time: li.getAttribute('data-time'), done: li.querySelector('input').checked })), 
                expenses: Array.from(document.querySelectorAll('#expenseList li')).map(li => ({ note: li.querySelector('.exp-note').innerText, amt: li.querySelector('.exp-amt').innerText.replace('৳', '') })), 
                accounts, habits, notebooks, activeNoteId, namaz,
                quickNotesArray, sleepStart, sleepEnd, sleepHours
            }; 
            await fetch(`db_handler.php?action=save&email=${userEmail}&date=${todayStr}`, { method: 'POST', body: JSON.stringify(data) }); 
        }

        function updateProgress() {
            let nP = Object.values(namaz).filter(v => v).length * 5, wP = Math.min(water * 2, 16);
            const ts = document.querySelectorAll('#taskList input');
            let total = ts.length + habits.length, done = Array.from(ts).filter(c => c.checked).length + habits.filter(h => h.checked).length;
            let workP = total > 0 ? (done / total) * 59 : 0;
            let final = Math.min(100, Math.round(nP + wP + workP));
            document.getElementById('progress-bar').style.width = final + '%';
            document.getElementById('progress-text').innerText = final + '%';
            updateSummaryCards();
        }

        function toggleNamaz(w) { 
            namaz[w] = !namaz[w]; 
            renderNamaz(); 
            updateProgress(); 
            saveData(); 
            buildAIInsights();
        }
        
        function renderNamaz() { 
            const prayers = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
            prayers.forEach(id => {
                const label = document.getElementById(`lbl-${id}`);
                const iconBox = document.getElementById(`icon-${id}`);
                const title = document.getElementById(`title-${id}`);
                const checkCircle = document.getElementById(`check-${id}`);
                const checkIcon = checkCircle.querySelector('i');

                if(!label) return;

                if (namaz[id]) {
                    label.className = "flex items-center justify-between p-4 rounded-2xl cursor-pointer transition-all duration-300 bg-emerald-500 border-2 border-emerald-500 shadow-md";
                    iconBox.className = "w-10 h-10 rounded-full flex items-center justify-center transition-colors bg-white/20 text-white";
                    title.className = "font-bold text-lg transition-colors text-white";
                    checkCircle.className = "w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors bg-white border-white";
                    checkIcon.className = "fas fa-check text-emerald-500 text-xs opacity-100 transition-opacity";
                } else {
                    label.className = "flex items-center justify-between p-4 rounded-2xl cursor-pointer transition-all duration-300 bg-white border-2 border-slate-200 hover:border-emerald-300";
                    iconBox.className = "w-10 h-10 rounded-full flex items-center justify-center transition-colors bg-slate-100 text-slate-500";
                    title.className = "font-bold text-lg transition-colors text-slate-700";
                    checkCircle.className = "w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors border-slate-300 bg-transparent";
                    checkIcon.className = "fas fa-check text-white text-xs opacity-0 transition-opacity";
                }
            });
        }

        function updateWaterUI() { document.getElementById('water-count').innerText = `${water}/৮`; }
        function addWater() { if(water < 12) { water++; updateWaterUI(); updateProgress(); saveData(); buildAIInsights(); } }
        function resetWater() { water = 0; updateWaterUI(); updateProgress(); saveData(); buildAIInsights(); }
        function setMood(m) { mood = m; document.querySelectorAll('.mood-btn').forEach(b => b.classList.remove('active')); if(m) { const b = document.getElementById('mood-'+m); if(b) b.classList.add('active'); } saveData(); buildAIInsights(); }
        
        function renderHabits() { document.getElementById('habitContainer').innerHTML = habits.map((h, i) => `<div class="flex items-center justify-between bg-slate-50 p-3 rounded-xl border"><div class="flex items-center gap-3 text-sm font-bold"><input type="checkbox" class="w-4 h-4 accent-orange-500 rounded" ${h.checked?'checked':''} onchange="habits[${i}].checked=!habits[${i}].checked; updateProgress(); saveData(); updateSummaryCards(); buildAIInsights();"> <span class="${h.checked?'completed':''} text-slate-700">${h.title}</span></div></div>`).join(''); }
        function renderSettingsHabits() { document.getElementById('settingsHabitList').innerHTML = habits.map((h, i) => `<div class="flex items-center justify-between bg-slate-50 p-2 rounded-lg"><span class="text-sm font-bold">${h.title}</span><i class="fas fa-trash text-red-300 cursor-pointer" onclick="openConfirmModal(() => { habits.splice(${i},1); renderSettingsHabits(); renderHabits(); updateProgress(); updateSummaryCards(); buildAIInsights(); })"></i></div>`).join(''); }
        function addNewHabit() { const v = document.getElementById('habitInputS').value; if(v) { habits.push({id: Date.now(), title: v, checked: false}); document.getElementById('habitInputS').value = ""; renderSettingsHabits(); renderHabits(); updateProgress(); updateSummaryCards(); buildAIInsights();} }

        function openSettings() {
            document.getElementById('set-fajr').value = namazTimes.fajr; document.getElementById('set-dhuhr').value = namazTimes.dhuhr;
            document.getElementById('set-asr').value = namazTimes.asr; document.getElementById('set-maghrib').value = namazTimes.maghrib;
            document.getElementById('set-isha').value = namazTimes.isha; 
            
            document.getElementById('set-daily-budget').value = extraSettings.dailyLimit;
            document.getElementById('set-monthly-budget').value = extraSettings.monthlyLimit;
            document.getElementById('set-bedtime').value = extraSettings.sleepTime;

            renderSettingsHabits();
            document.getElementById('settingsModal').classList.add('active');
        }
        function closeSettings() { document.getElementById('settingsModal').classList.remove('active'); }
        function saveAllSettings() {
            namazTimes = { fajr: document.getElementById('set-fajr').value, dhuhr: document.getElementById('set-dhuhr').value, asr: document.getElementById('set-asr').value, maghrib: document.getElementById('set-maghrib').value, isha: document.getElementById('set-isha').value };
            localStorage.setItem(`namaz_times_${userEmail}`, JSON.stringify(namazTimes)); 
            
            extraSettings = {
                dailyLimit: document.getElementById('set-daily-budget').value || 500,
                monthlyLimit: document.getElementById('set-monthly-budget').value || 15000,
                sleepTime: document.getElementById('set-bedtime').value || "22:00"
            };
            localStorage.setItem(`extra_settings_${userEmail}`, JSON.stringify(extraSettings));

            saveData(); closeSettings(); buildAIInsights();
        }

        function initSortable() {
            const load = (area) => {
                const order = JSON.parse(localStorage.getItem(`order_${area}_${userEmail}`));
                if (order) { const c = document.getElementById(area); order.forEach(id => { const el = c.querySelector(`[data-id="${id}"]`); if (el) c.appendChild(el); }); }
            };
            ['mainContentArea', 'sidebarArea'].forEach(area => {
                load(area);
                new Sortable(document.getElementById(area), { animation: 150, handle: '.drag-handle', ghostClass: 'sortable-ghost', onEnd: () => {
                    const order = Array.from(document.getElementById(area).children).map(el => el.getAttribute('data-id'));
                    localStorage.setItem(`order_${area}_${userEmail}`, JSON.stringify(order));
                } });
            });
        }

        function formatInsight(message, boxTitle, boxContent, colorClass, iconClass) {
            return `${message}
            <div class="mt-4 p-4 bg-${colorClass}-50 border border-${colorClass}-100 rounded-xl text-sm text-${colorClass}-800 font-medium leading-relaxed text-left">
                <span class="font-bold text-${colorClass}-700 block mb-1">
                    <i class="${iconClass}"></i> ${boxTitle}
                </span>
                ${boxContent}
            </div>`;
        }

        function buildAIInsights() {
            if (currentLoadedDate !== todayStr) return;
            activeAIInsights = [];
            const now = new Date();
            const currentMs = now.getTime();
            
            // 1. Prayer Check
            const prayerNamesRaw = { fajr: "ফজর", dhuhr: "যোহর", asr: "আসর", maghrib: "মাগরিব", isha: "এশা" };
            const prayerNamesPrefix = { fajr: "ফজরের", dhuhr: "যোহরের", asr: "আসরের", maghrib: "মাগরিবের", isha: "এশার" };
            let missedRaw = [], missedPrefix = [];
            
            for(let k in namazTimes) {
                const [h, m] = namazTimes[k].split(':').map(Number);
                if ((now.getHours() > h || (now.getHours() === h && now.getMinutes() >= m)) && !namaz[k]) {
                    missedRaw.push(prayerNamesRaw[k]); missedPrefix.push(prayerNamesPrefix[k]);
                }
            }
            if (missedRaw.length > 0) {
                let lastMissed = missedPrefix[missedPrefix.length - 1];
                let previousMissed = missedRaw.slice(0, -1);
                let msg = previousMissed.length === 0 
                    ? `আজকে আপনি এখনো <span class="text-emerald-600 font-bold">${lastMissed}</span> নামাজ আদায় করেন নাই।`
                    : `আপনি আজকে <span class="text-emerald-600 font-bold">${previousMissed.join(", ")}</span> এর নামাজ আদায় করেন নাই, এখন <span class="text-emerald-600 font-bold">${lastMissed}</span> নামাজ আদায় করেননি।`;
                
                activeAIInsights.push(formatInsight(msg, "আজকের হাদিস:", 'রাসূলুল্লাহ (সা.) বলেছেন, "কিয়ামত দিবসে বান্দার কাছ থেকে সর্বপ্রথম নামাজের হিসাব নেওয়া হবে।" <br><span class="text-xs text-emerald-600 mt-1 block">(সুনানে তিরমিযি: ৪১৩)</span>', "emerald", "fas fa-book-open"));
            }

            // 2. Water Check
            if(water < 8) {
                activeAIInsights.push(formatInsight(`আপনি পর্যাপ্ত পানি পান করছেন না। এ পর্যন্ত মাত্র <span class="text-blue-600 font-bold">${water} গ্লাস</span> খেয়েছেন।`, "ডাক্তারি টিপস:", "পর্যাপ্ত পানি পান কিডনি সুস্থ রাখে এবং মস্তিষ্ক সচল রাখতে সাহায্য করে। দ্রুত এক গ্লাস পানি পান করে নিন!", "blue", "fas fa-stethoscope"));
            }

            // 3. Task Overdue Check
            document.querySelectorAll('#taskList li').forEach(li => {
                if(li.querySelector('input').checked) return;
                const timeStr = li.getAttribute('data-time');
                if(!timeStr) return;
                const [h, m] = timeStr.split(':').map(Number);
                const taskTime = new Date(); taskTime.setHours(h, m, 0, 0);
                if (taskTime.getTime() < currentMs) {
                    let text = li.querySelector('.task-text').innerText;
                    activeAIInsights.push(formatInsight(`আপনি আপনার আজকের কাজ করেন নাই, দিনের সময় শেষ হয়ে যাচ্ছে!`, "পেন্ডিং কাজ:", `"${text}" কাজটি দ্রুত শেষ করুন। সময়ের কাজ সময়ে করা সফলতার চাবিকাঠি।`, "red", "fas fa-exclamation-circle"));
                }
            });

            // 4. Sleep Routine Check
            const [sh, sm] = extraSettings.sleepTime.split(':').map(Number);
            if (now.getHours() >= 22 || (now.getHours() > sh || (now.getHours() === sh && now.getMinutes() >= sm))) {
                activeAIInsights.push(formatInsight(`আপনার ঘুমানোর সময় হয়ে গেছে! রাত জাগা স্বাস্থ্যের জন্য ক্ষতিকর।`, "দ্রুত ঘুমানোর টিপস:", "মোবাইল বা স্ক্রিন দূরে সরিয়ে রাখুন। চোখ বন্ধ করে গভীর শ্বাস নিন, পেশী শিথিল করুন। পর্যাপ্ত ঘুম আগামীকাল আপনাকে কর্মোদ্যম রাখবে।", "indigo", "fas fa-moon"));
            }

            // 5. Routine Check
            let totalHabits = habits.length;
            let habitsDone = habits.filter(h => h.checked).length;
            if(totalHabits > 0 && habitsDone < totalHabits) {
                activeAIInsights.push(formatInsight(`আপনার আজকের রুটিন এখনো সম্পন্ন হয়নি!`, "উপদেশ:", "শৃঙ্খলাবদ্ধ জীবন মানুষকে তার কাঙ্ক্ষিত লক্ষে পৌঁছাতে সাহায্য করে। রুটিনগুলো দ্রুত শেষ করুন।", "orange", "fas fa-tasks"));
            }

            // 6. Expense Check
            let todayExp = 0; document.querySelectorAll('.exp-amt').forEach(s => todayExp += parseInt(s.innerText.replace('৳', '')) || 0);
            let dLimit = parseInt(extraSettings.dailyLimit), mLimit = parseInt(extraSettings.monthlyLimit);
            let baseMonthly = parseInt(localStorage.getItem(`mock_monthly_exp_${userEmail}`)) || 0; 
            if(todayExp > dLimit) {
                activeAIInsights.push(formatInsight(`আজকে আপনার খরচ ডেইলি বাজেট (৳${dLimit}) অতিক্রম করেছে!`, "আর্থিক উপদেশ:", "অযথা ব্যয় পরিহার করুন। সঞ্চয় ভবিষ্যতের বিপদের বন্ধু।", "teal", "fas fa-coins"));
            }

            // 7. Goals Check
            if(goals.length > 0) {
                let firstGoal = goals[0].title;
                activeAIInsights.push(formatInsight(`আপনার লক্ষ্যগুলোর কথা মনে আছে তো?`, "আপনার লক্ষ্য:", `"${firstGoal}" পূরণে আজ কি কোন পদক্ষেপ নিয়েছেন? ফোকাস ধরে রাখুন।`, "blue", "fas fa-bullseye"));
            }

            // 8. Mood Check
            if(mood === 'sad') activeAIInsights.push(formatInsight(`আপনার মন খারাপ দেখে আমারো খারাপ লাগছে।`, "পরামর্শ:", "কষ্টের পরেই আসে স্বস্তি। একটু বাইরে থেকে হেঁটে আসুন বা পছন্দের কিছু করুন।", "yellow", "fas fa-heart"));
            else if(mood === 'happy' || mood === 'amazing') activeAIInsights.push(formatInsight(`মাশাআল্লাহ! আপনি দারুণভাবে দিনটি পরিচালনা করছেন।`, "উপদেশ:", "আপনার এই খুশির ধারা বজায় থাকুক, এই পজিটিভ এনার্জি দিয়ে কাজগুলো দ্রুত শেষ করুন।", "yellow", "fas fa-star"));

            if(activeAIInsights.length === 0) activeAIInsights.push(`আপনি দারুণভাবে সবকিছু ম্যানেজ করছেন! এভাবে চালিয়ে যান। 👍`);
        }

        function rotateAIInsights() {
            if(activeAIInsights.length === 0) return;
            const msgEl = document.getElementById('aiMessage');
            msgEl.style.opacity = 0;
            setTimeout(() => {
                msgEl.innerHTML = activeAIInsights[currentInsightIndex];
                msgEl.style.opacity = 1;
                currentInsightIndex = (currentInsightIndex + 1) % activeAIInsights.length;
            }, 500);
        }

        function logout() { localStorage.clear(); window.location.href = 'index.html'; }
    </script>
</body>
</html>