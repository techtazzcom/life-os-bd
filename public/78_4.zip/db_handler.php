<?php
header('Content-Type: application/json');

// আপনার হোস্টিংগারের ডাটাবেস তথ্য এখানে দিন
$host = 'localhost';
$db_name = 'u820759092_life';
$db_user = 'u820759092_life';
$db_pass = 'S7!i4;Ug7@p';

$conn = new mysqli($host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Connection failed']));
}

$action = $_GET['action'] ?? '';
$email = $_GET['email'] ?? '';
$date = $_GET['date'] ?? date('Y-m-d');

// ডাটা সেভ করা
if ($action === 'save') {
    $json_data = file_get_contents('php://input');
    $stmt = $conn->prepare("INSERT INTO lifeos_data (email, date_key, data_content) VALUES (?, ?, ?) 
                            ON DUPLICATE KEY UPDATE data_content = ?");
    $stmt->bind_param("ssss", $email, $date, $json_data, $json_data);
    if($stmt->execute()) echo json_encode(['status' => 'success']);
} 

// ডাটা লোড করা
if ($action === 'load') {
    $stmt = $conn->prepare("SELECT data_content FROM lifeos_data WHERE email = ? AND date_key = ?");
    $stmt->bind_param("ss", $email, $date);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    echo $row['data_content'] ?? json_encode(null);
}

$conn->close();
?>